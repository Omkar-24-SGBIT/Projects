from django.apps import AppConfig


class PhishingdetectionConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "phishingDetection"
